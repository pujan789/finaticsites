<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://www.crantia.com/wp-content/themes/crantianewtheme/css/style.css" rel="stylesheet">
    <title>404</title>
</head>
<body>
<div class="four-not-four">
   <div>
       <div class="error">
        
           <img src="https://www.crantia.com/wp-content/themes/crantianewtheme/images/error.webp" alt="error">
           </div>
       
           <div class="error-text">
               <h2>Page not found</h2>
               <p>We're sorry the page you requested could not be found please go back to the homepage</p>
           <a href="https://www.crantia.com">Go Home</a>
           </div>
   </div>
   </div>   
</body>
</html>

